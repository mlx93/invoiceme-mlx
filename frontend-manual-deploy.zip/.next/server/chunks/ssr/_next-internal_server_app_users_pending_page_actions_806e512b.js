module.exports=[14394,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_users_pending_page_actions_806e512b.js.map