module.exports=[8307,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_recurring-invoices_page_actions_981e9ef9.js.map