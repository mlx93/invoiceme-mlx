module.exports=[61250,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_invoices_%5Bid%5D_refund_page_actions_68dcde1b.js.map