module.exports=[79974,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_invoices_new_page_actions_e0936958.js.map