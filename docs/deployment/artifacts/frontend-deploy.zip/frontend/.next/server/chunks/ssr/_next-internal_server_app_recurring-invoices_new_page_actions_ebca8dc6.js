module.exports=[1976,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_recurring-invoices_new_page_actions_ebca8dc6.js.map