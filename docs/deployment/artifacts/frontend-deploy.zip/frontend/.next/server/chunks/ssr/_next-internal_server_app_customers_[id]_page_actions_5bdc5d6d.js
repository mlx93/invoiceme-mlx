module.exports=[30358,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_customers_%5Bid%5D_page_actions_5bdc5d6d.js.map