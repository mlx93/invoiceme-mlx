module.exports = [
"[project]/.next-internal/server/app/invoices/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_invoices_page_actions_949cb4db.js.map