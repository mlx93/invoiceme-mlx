module.exports = [
"[project]/.next-internal/server/app/users/pending/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_users_pending_page_actions_806e512b.js.map