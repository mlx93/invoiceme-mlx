module.exports=[82575,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_customers_new_page_actions_2837c48a.js.map