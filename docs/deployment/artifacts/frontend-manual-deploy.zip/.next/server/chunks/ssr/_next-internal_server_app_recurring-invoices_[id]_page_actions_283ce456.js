module.exports=[72592,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_recurring-invoices_%5Bid%5D_page_actions_283ce456.js.map