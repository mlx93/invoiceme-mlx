module.exports=[96669,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_page_actions_7f01ccec.js.map