module.exports=[30307,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_invoices_%5Bid%5D_page_actions_9b210080.js.map