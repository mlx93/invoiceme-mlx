module.exports=[94455,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_invoices_page_actions_949cb4db.js.map