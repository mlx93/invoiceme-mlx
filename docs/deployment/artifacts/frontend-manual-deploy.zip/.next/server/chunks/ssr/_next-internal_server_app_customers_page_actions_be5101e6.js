module.exports=[27330,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_customers_page_actions_be5101e6.js.map