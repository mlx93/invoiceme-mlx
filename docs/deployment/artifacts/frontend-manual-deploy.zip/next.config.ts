import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Remove output config - let Amplify auto-detect
};

export default nextConfig;
